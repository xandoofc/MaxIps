<?php

namespace spokkernetwork\maxips;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->saveDefaultConfig();
        $this->copyLanguageFiles();
        $this->loadLanguage();
        $this->createPlayerFolders();
    }

    public function onPlayerJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $ip = $player->getAddress();

        $config = new Config($this->getDataFolder() . "players/" . $ip . ".yml", Config::YAML);
        $playerList = $config->get("players", []);

        if (count($playerList) >= $this->getConfig()->get("MaxAccounts") && !in_array($player->getName(), $playerList)) {
            $player->kick($this->getMessage("max_accounts_reached"));
            return;
        }

        if (!in_array($player->getName(), $playerList)) {
            $playerList[] = $player->getName();
            $config->set("players", $playerList);
            $config->save();
        }
    }

    private function copyLanguageFiles() {
        $languages = ["en", "pt", "es", "ru"];
        $pluginDataFolder = $this->getDataFolder();

        foreach ($languages as $language) {
            $resourcePath = $this->getFile() . "resources/language/{$language}.yml";
            $dataPath = $pluginDataFolder . "language/{$language}.yml";

            if (!file_exists($dataPath)) {
                $this->saveResource("language/{$language}.yml", false);
            }
        }
    }

    private function loadLanguage() {
        $language = $this->getConfig()->get("Language", "en");
        $languageFile = $this->getDataFolder() . "language/{$language}.yml";

        if (file_exists($languageFile)) {
            $this->language = new Config($languageFile, Config::YAML);
        } else {
            $this->getLogger()->warning("Language file '{$language}.yml' not found. Defaulting to English.");
            $this->language = new Config($this->getFile() . "resources/language/en.yml", Config::YAML);
        }
    }

    private function getMessage(string $key): string {
        return $this->language->get($key, $key);
    }

    private function createPlayerFolders() {
        $playersFolder = $this->getDataFolder() . "players/";
        if (!is_dir($playersFolder)) {
            mkdir($playersFolder, 0777, true);
        }
    }
}
